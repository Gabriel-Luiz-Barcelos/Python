num= int(input('digite o número para saber se é par ou ímpar: '))

if (num % 2) != 0:
    print('o número é impar')
else:
    print('número é par')